Action()
{

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("banking", 
		"URL=http://localhost/banking/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722470464381\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(19);

	lr_start_transaction("Apply_Debit_card");

	web_url("Apply Debit Card", 
		"URL=http://localhost/banking/debit_card_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);

	lr_think_time(52);

	lr_start_transaction("Enter_details_submit");

	web_submit_data("debit_card_form.php", 
		"Action=http://localhost/banking/debit_card_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/debit_card_form.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=holder_name", "Value=Sita", ENDITEM, 
		"Name=dob", "Value=1994-06-20", ENDITEM, 
		"Name=pan", "Value=VISH8976N", ENDITEM, 
		"Name=mob", "Value=9699057202", ENDITEM, 
		"Name=acc_no", "Value=1011831011314", ENDITEM, 
		"Name=dbt_crd_submit", "Value=Submit Query", ENDITEM, 
		LAST);

	lr_think_time(40);

	lr_start_transaction("Click_OK");

	lr_start_transaction("Click_Home");

	web_url("Home", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/debit_card_form.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(31);

	lr_start_transaction("Click_internet_banking_register");

	web_url("Register", 
		"URL=http://localhost/banking/ebanking_reg_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/index.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(52);

	lr_start_transaction("Enter_banking_details");

	web_submit_data("ebanking_reg_form.php", 
		"Action=http://localhost/banking/ebanking_reg_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/ebanking_reg_form.php", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=holder_name", "Value=Sita", ENDITEM, 
		"Name=accnum", "Value=1011831011314", ENDITEM, 
		"Name=dbtcard", "Value=421329876565", ENDITEM, 
		"Name=dbtpin", "Value=1712", ENDITEM, 
		"Name=mobile", "Value=9699057202", ENDITEM, 
		"Name=pan_no", "Value=VISH8976N", ENDITEM, 
		"Name=dob", "Value=1994-06-20", ENDITEM, 
		"Name=last_trans", "Value=0", ENDITEM, 
		"Name=password", "Value=vish123", ENDITEM, 
		"Name=cnfrm_password", "Value=vish123", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);

	lr_think_time(85);

	lr_start_transaction("Click_ok_cust_id");

	lr_start_transaction("Click_Home1");

	web_url("Home_2", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/ebanking_reg_form.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(21);

	lr_start_transaction("Click_internet_banking_login");

	web_url("Login", 
		"URL=http://localhost/banking/customer_login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/index.php", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(49);

	lr_start_transaction("Login_internet_banking");

	web_submit_data("customer_login.php", 
		"Action=http://localhost/banking/customer_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_login.php", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=customer_id", "Value=Sita", ENDITEM, 
		"Name=password", "Value=vish123", ENDITEM, 
		"Name=login-btn", "Value=LOGIN", ENDITEM, 
		LAST);

	lr_start_transaction("Click_banking_login1");

	web_submit_data("customer_login.php_2", 
		"Action=http://localhost/banking/customer_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_login.php", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=customer_id", "Value=1011314 ", ENDITEM, 
		"Name=password", "Value=vish123", ENDITEM, 
		"Name=login-btn", "Value=LOGIN", ENDITEM, 
		EXTRARES, 
		"Url=img/customers/No_image.jpg", "Referer=http://localhost/banking/customer_profile.php", ENDITEM, 
		LAST);

	lr_think_time(178);

	lr_start_transaction("Click_my_Acc");

	web_url("My Account", 
		"URL=http://localhost/banking/customer_profile_myacc.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_profile.php", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Logout");

	web_url("customer_logout.php", 
		"URL=http://localhost/banking/customer_logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_profile_myacc.php", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}