Action()
{
 
	long file;
	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
	
    lr_start_transaction("S03_OnlineBanking_T01_LaunchPage");
	
	web_reg_find("Text=Online Banking System","SaveCount=LaunchPage",LAST);
	web_url("banking", 
		"URL=http://localhost/banking/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{LaunchPage}"))>0)
        
    {
     lr_end_transaction("S03_OnlineBanking_T01_LaunchPage", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T01_LaunchPage", LR_FAIL);
   }

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722470464381\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(tt);

	lr_start_transaction("S03_OnlineBanking_T02_ApplyDebitCard");
	
	web_reg_find("Text=Apply Debit Card","SaveCount=Apply_Debit",LAST);

	web_url("Apply Debit Card", 
		"URL=http://localhost/banking/debit_card_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{Apply_Debit}"))>0)

        
    {
     lr_end_transaction("S03_OnlineBanking_T02_ApplyDebitCard", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T02_ApplyDebitCard", LR_FAIL);
   }
	
	//lr_end_transaction("S03_OnlineBanking_T02_ApplyDebitCard",LR_AUTO);

	lr_think_time(52);

	lr_start_transaction("S03_OnlineBanking_T03_CaptureValues");
	
	web_reg_find("Text=Apply Debit Card","SaveCount=CaptureValue",LAST);
	
web_reg_save_param("C_Debit_card",
 
        "LB=Debit Card No is :",
        "RB=and",
        LAST);
	
	web_reg_save_param("C_Debit_pin",
		"LB=Pin is : ",
		"RB=\\",
		LAST);

	web_submit_data("debit_card_form.php", 
		"Action=http://localhost/banking/debit_card_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/debit_card_form.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=holder_name", "Value={P_Name}", ENDITEM, 
		"Name=dob", "Value=2005-02-02", ENDITEM, 
		"Name=pan", "Value={P_PanNo}", ENDITEM, 
		"Name=mob", "Value={P_MobNo}", ENDITEM, 
		"Name=acc_no", "Value={P_AccountNo}", ENDITEM, 
		"Name=dbt_crd_submit", "Value=Submit Query", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{CaptureValue}"))>0)

        
    {
     lr_end_transaction("S03_OnlineBanking_T03_CaptureValues", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T03_CaptureValues", LR_FAIL);
   }
   
	//lr_end_transaction("S03_OnlineBanking_T03_CaptureValues",LR_AUTO);

	lr_think_time(40);

	//lr_start_transaction("Click_OK");

	lr_start_transaction("S03_OnlineBanking_T04_ClickHome");
	
	web_reg_find("Text=Online Banking System","SaveCount=Home",LAST);

	web_url("Home", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/debit_card_form.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{Home}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T04_ClickHome", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T04_ClickHome", LR_FAIL);
   }
	
	//lr_end_transaction("S03_OnlineBanking_T04_ClickHome",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("S03_OnlineBanking_T05_SelectIB_Register");
	
	web_reg_find("Text=Internet Banking Registration","SaveCount=Banking",LAST);

	web_url("Register", 
		"URL=http://localhost/banking/ebanking_reg_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/index.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{Banking}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T05_SelectIB_Register", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T05_SelectIB_Register", LR_FAIL);
   }
	
	//lr_end_transaction("S03_OnlineBanking_T05_SelectIB_Register",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("S03_OnlineBanking_T06_RegisterAccount");
	
	web_reg_find("Text=Internet Banking Registration","SaveCount=Registration",LAST);
	
	web_reg_save_param("C_customerId","LB=Customer ID : ","RB=\\",LAST);

	web_submit_data("ebanking_reg_form.php", 
		"Action=http://localhost/banking/ebanking_reg_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/ebanking_reg_form.php", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=holder_name", "Value={P_Name}", ENDITEM, 
		"Name=accnum", "Value={P_AccountNo}", ENDITEM, 
		"Name=dbtcard", "Value={C_Debit_card}", ENDITEM, 
		"Name=dbtpin", "Value={C_Debit_pin}", ENDITEM, 
		"Name=mobile", "Value={P_MobNo}", ENDITEM, 
		"Name=pan_no", "Value={P_PanNo}", ENDITEM, 
		"Name=dob", "Value=2005-02-02", ENDITEM, 
		"Name=last_trans", "Value=0", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		"Name=cnfrm_password", "Value={P_Password}", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{Registration}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T06_RegisterAccount", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T06_RegisterAccount", LR_FAIL);
   }
	
	//lr_end_transaction("S03_OnlineBanking_T06_RegisterAccount",LR_AUTO);

	lr_think_time(tt);

	//lr_start_transaction("Click_ok_cust_id");

	lr_start_transaction("S03_OnlineBanking_T07_ClickHome");
	
	web_reg_find("Text=Online Banking System","SaveCount=ClickHome",LAST);

	web_url("Home_2", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/ebanking_reg_form.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{ClickHome}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T07_ClickHome", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T07_ClickHome", LR_FAIL);
   }
	//lr_end_transaction("S03_OnlineBanking_T07_ClickHome",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("S03_OnlineBanking_T08_SelectIR_Login");
	
	web_reg_find("Text=Login Page","SaveCount=Login_Successful",LAST);
	
	web_url("Login", 
		"URL=http://localhost/banking/customer_login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/index.php", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
		
	web_reg_save_param("C_availableBalance",
 
        "LB=Available Balance : ",
        "RB=<",
        LAST);
	
	web_submit_data("customer_login.php_2", 
		"Action=http://localhost/banking/customer_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_login.php", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=customer_id", "Value={C_customerId} ", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		"Name=login-btn", "Value=LOGIN", ENDITEM, 
		EXTRARES, 
		"Url=img/customers/No_image.jpg", "Referer=http://localhost/banking/customer_profile.php", ENDITEM, 
		LAST);
		
		if(atoi(lr_eval_string("{Login_Successful}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T08_SelectIR_Login", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T08_SelectIR_Login", LR_FAIL);
   }
	
   lr_think_time(tt);
	
	lr_start_transaction("S03_OnlineBanking_T09_ClickAccount");
	
	web_reg_find("Text=My Account","SaveCount=My_Acc",LAST);

	web_url("My Account", 
		"URL=http://localhost/banking/customer_profile_myacc.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_profile.php", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);
	
	if(atoi(lr_eval_string("{My_Acc}"))>0)
     
    {
     lr_end_transaction("S03_OnlineBanking_T09_ClickAccount", LR_PASS);    
    }
   else
   {
       lr_end_transaction("S03_OnlineBanking_T09_ClickAccount", LR_FAIL);
   }
	
	 //lr_end_transaction("S03_OnlineBanking_T09_ClickAccount",LR_AUTO);
	 
	 lr_think_time(tt);

	lr_start_transaction("S03_OnlineBanking_T10_LogOut");

	web_url("customer_logout.php", 
		"URL=http://localhost/banking/customer_logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_profile_myacc.php", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);
	
	  lr_end_transaction("S03_OnlineBanking_T10_LogOut",LR_AUTO);
	
		file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Debit Card Details.txt","a+");
        fprintf(file,"%s",lr_eval_string("Debit card :{C_Debit_card} , Debit Pin:{C_Debit_pin}\n"));
        fclose(file);
        
        file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Internet Banking Accounts.txt","a+");
        fprintf(file,"%s",lr_eval_string("UserName:{C_customerId} , Password:{P_Password}\n"));
        fclose(file);
        
        

	return 0;
}