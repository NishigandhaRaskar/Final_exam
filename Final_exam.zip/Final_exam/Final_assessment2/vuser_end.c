vuser_end()
{
	//long file;
	//long file1;
	
	lr_start_transaction("SC02_Banking_T07_Logout");

	web_url("staff_logout.php", 
		"URL=http://localhost/banking/staff_logout.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("SC02_Banking_T07_Logout",LR_AUTO);
	
	

        	
	return 0;
}
