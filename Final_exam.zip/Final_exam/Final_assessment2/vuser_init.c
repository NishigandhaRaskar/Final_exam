vuser_init()
{
	
	lr_start_transaction("SC02_Banking_T01_Launch_URL");
	
	//web_reg_find("Text=Your Store","SaveCount=Launch", LAST);
	
	web_url("banking", 
		"URL=http://localhost/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722394630668\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);
	lr_end_transaction("SC02_Banking_T01_Launch_URL",LR_AUTO);
	
	 
	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(tt);
	

	lr_start_transaction("SC02_Banking_T02_Staff_Login");
	
	 web_reg_find("text=Staff Page","SaveCount=Staff_Login", LAST);

	web_url("Staff Login", 
		"URL=http://localhost/banking/staff_login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);
	
	//lr_end_transaction("SC02_Banking_T02_Staff_Login",LR_AUTO);
	
	
     if(atoi(lr_eval_string("{Staff_Login}"))>0)
 
{
    lr_end_transaction("SC02_Banking_T02_Staff_Login", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC02_Banking_T02_Staff_Login", LR_FAIL);
        
        
      return 0;
    }
	
	lr_think_time(tt);

	lr_start_transaction("SC02_Banking_T03_Click_Login");
	
	web_reg_find("text=Staff Page","SaveCount=Login_Successful", LAST);
	
	/*Correlation comment - Do not change!  Original value='Approve' Name ='approve_cust' Type ='ResponseBased'*/
//	web_reg_save_param_regexp(
//		"ParamName=approve_cust",
//		"RegExp=name=\"apprvac\"\\ value=\"(.*?)\\ Pending\\ Account",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"IgnoreRedirections=Yes",
//		"RequestUrl=*/staff_profile.php*",
//		LAST);

	web_submit_data("staff_login.php", 
		"Action=http://localhost/banking/staff_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_login.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=staff_id", "Value=210001", ENDITEM, 
		"Name=password", "Value=password", ENDITEM, 
		"Name=staff_login-btn", "Value=LOGIN", ENDITEM, 
		EXTRARES, 
		"Url=img/customers/No_image.jpg", "Referer=http://localhost/banking/staff_profile.php", ENDITEM, 
		LAST);
	
	
	    if(atoi(lr_eval_string("{Login_Successful}"))>0)
 
{
    lr_end_transaction("SC02_Banking_T03_Click_Login", LR_PASS);
}
    else
    {
    	
     //lr_end_transaction("SC02_Banking_T03_Click_Login", LR_FAIL);
      
     //LR(lr_exit_iteration_and_continue, LR_FAIL);   
   
      lr_error_message("Login_Failed");

      lr_exit(LR_EXIT_MAIN_ITERATION_AND_CONTINUE, LR_AUTO);   
      
      return 0;
    }
	
		
	lr_think_time(tt);
	
	
	return 0;
}
