Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");

	web_url("remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"URL=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	
		lr_start_transaction("SC02_Banking_T04_Click_Approve_pending_Acc");
		
		web_reg_find("text=Staff Page","SaveCount=Pending_Approval", LAST);
		
		web_submit_data("staff_profile.php_2", 
		"Action=http://localhost/banking/staff_profile.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_profile.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=apprvac", "Value=Approve Pending Account", ENDITEM, 
		LAST);
//		
//	if(atoi(lr_eval_string("{Pending_Approval}"))>0)
// 
//{
//    lr_end_transaction("SC02_Banking_T04_Click_Approve_pending_Acc", LR_PASS);
//}
//    else
//    {
//    	
//     lr_end_transaction("SC02_Banking_T04_Click_Approve_pending_Acc", LR_FAIL);
//        
//        
//      return 0;
//    }	
	
	lr_end_transaction("SC02_Banking_T04_Click_Approve_pending_Acc",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("SC02_Banking_T05_Search_Application_number");
	
	web_reg_find("text=application_no","SaveCount=App_No", LAST);
	
//	web_reg_save_param("C_Details",
//		"LB=<td>",
//		"RB=</td",
//		//"NotFound=ERROR",
//		"ORD=ALL",
//		LAST);
	
	web_reg_save_param_regexp(
 
        "ParamName=C_name",
        "RegExp=<td>(.*?)</td>",
        "Group=1",
        "Ordinal=3",
        SEARCH_FILTERS,
        LAST);
	
	web_reg_save_param_regexp(
 
        "ParamName=C_PanNo",
        "RegExp=<td>(.*?)</td>",
        "Group=1",
        "Ordinal=9",
        SEARCH_FILTERS,
        LAST);
	
	web_reg_save_param_regexp(
 
        "ParamName=C_Email",
        "RegExp=<td>(.*?)</td>",
        "Group=1",
        "Ordinal=6",
        SEARCH_FILTERS,
        LAST);
	
	web_reg_save_param_regexp(
 
        "ParamName=C_MobNo",
        "RegExp=<td>(.*?)</td>",
        "Group=1",
        "Ordinal=5",
        SEARCH_FILTERS,
        LAST);
	
	
	web_submit_data("pending_customers.php", 
		"Action=http://localhost/banking/pending_customers.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=application_no", "Value={P_Application_No}", ENDITEM, 
		"Name=search_application", "Value=Search", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{App_No}"))>0)
 
{
    lr_end_transaction("SC02_Banking_T05_Search_Application_number", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC02_Banking_T05_Search_Application_number", LR_FAIL);
        
        
      return 0;
    }	
	
	//lr_end_transaction("SC02_Banking_T05_Search_Application_number",LR_AUTO);

	lr_think_time(tt);
	
	if(strcmp(lr_eval_string("C_Email"), "P_Email")==0);
	{
		if(strcmp(lr_eval_string("C_PanNo"), lr_eval_string("P_PanNo"))==0);
		{
		 if(strcmp(lr_eval_string("C_name"), lr_eval_string("P_Name"))==0);	
		
	

	lr_start_transaction("SC02_Banking_T06_Click_Approve");
	
	web_reg_find("text=Approve","SaveCount=Approval", LAST);
	
	web_reg_save_param("C_AccountNumber",
		"LB=Account no :",
		"RB=\\",
		//"NotFound=ERROR",
		LAST);

	web_submit_data("pending_customers.php_2",
		"Action=http://localhost/banking/pending_customers.php",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost/banking/pending_customers.php",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=approve_cust", "Value=Approve", ENDITEM,
		LAST);
	
	if(atoi(lr_eval_string("{Approval}"))>0)
 
{
    lr_end_transaction("SC02_Banking_T06_Click_Approve", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC02_Banking_T06_Click_Approve", LR_FAIL);
        
        
      return 0;
    }
	}
	}

	//lr_end_transaction("SC02_Banking_T06_Click_Approve",LR_AUTO);

	//lr_start_transaction("T07_Click_OK");
	
	lr_think_time(tt);

        
        file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\VerifiedAccounts.txt","a+");
        fprintf(file,"%s",lr_eval_string("Account_Number:{C_AccountNumber}\n"));
        fclose(file);
        

        file1 = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Name.txt","a+");
        fprintf(file1,"%s",lr_eval_string("{C_name},{C_AccountNumber},{C_PanNo},{C_MobNo}\n"));
        fclose(file1);        

          
	return 0;
}