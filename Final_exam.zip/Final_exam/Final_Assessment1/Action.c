Action()
{

char random_value[11];	
const char alphanum[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
int k;
long file;


	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.5");
	
	lr_start_transaction("SC01_Banking_T01_Launch_URL");

	web_url("banking", 
		"URL=http://localhost/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722394630668\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);
	
	lr_end_transaction("SC01_Banking_T01_Launch_URL",LR_AUTO);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_think_time(tt);

	lr_start_transaction("SC01_Banking_T02_Click_Open_Account");
	
	web_reg_find("text=Registration Form","SaveCount=Account", LAST);
	
	web_reg_save_param("C_State",
		"LB=option value=\"",
		"RB=\">",
		"NotFound=ERROR",
		"ORD=ALL",
		LAST);
	
	web_reg_save_param("C_City",
		"LB=option value=\"",
		"RB=\">",
		"NotFound=ERROR",
		"ORD=ALL",
		LAST);

	web_url("Open Account", 
		"URL=http://localhost/banking/customer_reg_form.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{Account}"))>0)
 
{
    lr_end_transaction("SC01_Banking_T02_Click_Open_Account", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC01_Banking_T02_Click_Open_Account", LR_FAIL);
        
        
      return 0;
    }	
	
	//lr_end_transaction("SC01_Banking_T02_Click_Open_Account",LR_AUTO);

	//lr_start_transaction("T03_Fill_Account_Opening_Form");
	
   lr_think_time(tt);

   lr_start_transaction("SC01_Banking_T03_Click_Submit");
   
   	for(k=0; k< 10; k++)
{
    random_value[k]=alphanum[rand() % (sizeof (alphanum) - 1)];
    
}
random_value[11]= '\0';

//lr_error_message(random_value);
lr_save_string(random_value,"Pan_NO");

   web_reg_find("text=Registration Form","SaveCount=Submit", LAST);
   
   lr_save_string(lr_paramarr_random("C_State"),("C_RandomState"));
   lr_save_string(lr_paramarr_random("C_City"),("C_RandomCity"));

	web_submit_data("customer_reg_form.php", 
		"Action=http://localhost/banking/customer_reg_form.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/customer_reg_form.php", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value={P_Name}", ENDITEM, 
		"Name=gender", "Value=Female", ENDITEM, 
		"Name=mobile", "Value={P_MobNo}", ENDITEM, 
		"Name=email", "Value={P_Email}", ENDITEM, 
		"Name=landline", "Value=123456", ENDITEM, 
		"Name=dob", "Value=2005-02-02", ENDITEM, 
		"Name=pan_no", "Value={Pan_NO}", ENDITEM, 
		"Name=citizenship", "Value={P_Citizenship}", ENDITEM, 
		"Name=homeaddrs", "Value={P_HomeAdd}", ENDITEM, 
		"Name=officeaddrs", "Value={P_OfficeAdd}", ENDITEM, 
		"Name=country", "Value=US", ENDITEM, 
		"Name=state", "Value={C_RandomState}", ENDITEM, 
		"Name=city", "Value={C_RandomCity}", ENDITEM, 
		"Name=pin", "Value={P_Pincode}", ENDITEM, 
		"Name=arealoc", "Value=ABC", ENDITEM, 
		"Name=nominee_name", "Value=NA", ENDITEM, 
		"Name=nominee_ac_no", "Value={P_AccountNo}", ENDITEM, 
		"Name=acctype", "Value=Saving", ENDITEM, 
		"Name=submit", "Value=Submit", ENDITEM, 
		LAST);
   
   if(atoi(lr_eval_string("{Submit}"))>0)
 
{
    lr_end_transaction("SC01_Banking_T03_Click_Submit", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC01_Banking_T03_Click_Submit", LR_FAIL);
        
        
      return 0;
    }	
 
		
    //lr_end_transaction("SC01_Banking_T03_Click_Submit",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("SC01_Banking_T04_Click_confirm");
	
	
	web_reg_find("text=Online Banking System","SaveCount=Confirm", LAST);
	
	web_set_max_html_param_len("200000");
	
	web_reg_save_param("C_ApplicationNumber",
 
        "LB=Application number : ",
        "RB=\\",
        LAST);
	
//	   web_reg_save_param_regexp(
//        "ParamName=C_ApplicationNumber",
//        "RegExp=Application number : (.*)\n",
//        SEARCH_FILTERS,
//        "Scope=Body",
//        "IgnoreRedirections=No",
//        LAST);


	web_submit_data("cust_regfrm_confirm.php", 
		"Action=http://localhost/banking/cust_regfrm_confirm.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cnfrm-submit", "Value=Confirm", ENDITEM, 
		LAST);
		
		 if(atoi(lr_eval_string("{Confirm}"))>0)
 
{
    lr_end_transaction("SC01_Banking_T04_Click_confirm", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC01_Banking_T04_Click_confirm", LR_FAIL);
        
        
      return 0;
    }	
	
	//lr_end_transaction("SC01_Banking_T04_Click_confirm",LR_AUTO);

	lr_think_time(tt);

	lr_start_transaction("SC01_Banking_T05_Click_OK");
	
	web_reg_find("text=Online Banking System","SaveCount=Click_ok", LAST);

	web_url("Home", 
		"URL=http://localhost/banking/index.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/cust_regfrm_confirm.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
	
	 if(atoi(lr_eval_string("{Click_ok}"))>0)
 
{
    lr_end_transaction("SC01_Banking_T05_Click_OK", LR_PASS);
}
    else
    {
    	
     lr_end_transaction("SC01_Banking_T05_Click_OK", LR_FAIL);
        
        
      return 0;
    }	
	
	//lr_end_transaction("SC01_Banking_T05_Click_OK",LR_AUTO);
	
	lr_output_message("To verify   %s",lr_eval_string(" State:{C_RandomState}; City:{C_RandomCity}; PanNo:{Pan_NO}; Application_Number:{C_ApplicationNumber}; DOB:; HomeAddress:{P_HomeAdd}; Email_ID:{P_Email} "));
	
	file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Applications.txt","a+");
        fprintf(file,"%s",lr_eval_string("Application_Number:{C_ApplicationNumber},Name :{P_Name},PanNo:{Pan_NO}, EmailID: {P_Email} ;Citizenship:{P_Citizenship},State:{C_RandomState},City:{C_RandomCity}\n"));
        fclose(file);
        
        file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Applications_Number.txt","a+");
        fprintf(file,"%s",lr_eval_string("{C_ApplicationNumber}\n"));
        fclose(file);

        	file = fopen("C:\\Users\\Administrator\\Documents\\VuGen\\Scripts\\Final_Ass\\Application1.txt","a+");
        fprintf(file,"%s",lr_eval_string("{P_Name},{Pan_NO},{P_Email}\n"));
        fclose(file);
	return 0;
}